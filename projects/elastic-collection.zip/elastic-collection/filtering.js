console.log("Hello, Airtable");

let wrapper = document.querySelector(".wrapper");

let Airtable = require("airtable");
console.log(Airtable);


var base = new Airtable({ apiKey: "keyLhnFLSZbCgVtB2" }).base(
  "appextHbNAglZqO1g"
);

base("tiktokfood").select({}).eachPage(gotPageOfRecipes, 
    gotAllRecipes);

var recipes = [];

function gotPageOfRecipes(records, fetchNextPage) {
  console.log("gotPageOfRecipes()");
  
  recipes.push(...records);
  
  fetchNextPage();
}

function gotAllRecipes(err) {
    console.log("gotAllRecipes()");
    if (err) {
      console.log("error loading data");
      console.error(err);
      return;
    }
    
    consoleLogRecipes();
    showRecipes();
  }
  
function consoleLogRecipes() {
    console.log("consoleLogRecipes()");
    recipes.forEach((recipe) => {
      console.log("Recipe:", recipe);
    });
  }
  
  function showRecipes() {
    console.log("showRecipes()");
    recipes.forEach((recipe) => {

        var recipeTitle = document.createElement("div");
        recipeTitle.classList.add("recipeTitle");
        recipeTitle.innerText = recipe.fields.name;
        wrapper.append(recipeTitle);

        var recipeLikes = document.createElement("h3");
        recipeLikes.classList.add("likes");
        recipeLikes.innerText = recipe.fields.likes;
        wrapper.append(recipeLikes);

        var recipeUser = document.createElement("h4");
        recipeUser.classList.add("user");
        recipeUser.innerText = recipe.fields.user;
        wrapper.append(recipeUser);

        var recipeType = document.createElement("h5");
        recipeType.classList.add("type");
        recipeType.innerText = recipe.fields.type;
        wrapper.append(recipeType);

        var recipeIngredients = document.createElement("section");
        recipeIngredients.classList.add("ingredients");
        recipeIngredients.innerText = recipe.fields.ingredients;
        wrapper.append(recipeIngredients);

        let videoHolder = document.createElement("video");
        videoHolder.src = recipe.fields.video[0].url;
        videoHolder.classList.add("tiktokvideo");
        videoHolder.muted = true;
        videoHolder.autoplay = true;
        videoHolder.loop = true;
        wrapper.appendChild(videoHolder);

        const slugify = function(name) {
            return name.toLowerCase().replaceAll(' ', '-');
        };
        
          
        let type = recipe.fields.type;
        type.forEach(function(type) {
          let typeClassName = slugify(type);
          console.log('typeClassName', typeClassName);
          videoHolder.classList.add(typeClassName);
        });
        
        // add event listener to our filter to add an active class to our video
        let filterEntree = document.querySelector(".entree");
        let entreebutton = document.querySelector(".entreebutton");
        filterEntree.addEventListener("click", function(){
          if (videoHolder.classList.contains("entree")) {
            videoHolder.style.display = "block";
            entreebutton.classList.add("active");
          } else {
            videoHolder.style.display = "none";
          }
        });
        
        let filterSnack = document.querySelector(".snack");
        let snackbutton = document.querySelector(".snackbutton");
        filterSnack.addEventListener("click", function(){
          if (videoHolder.classList.contains("snack")) {
            videoHolder.style.display = "block";
            snackButton.classList.add("active");
          } else {
            videoHolder.style.display = "none";
            snackbutton.classList.remove("active");
          }
        });
        
        let filterSideDish = document.querySelector(".sidedish");
        let sidedishbutton = document.querySelector(".sidedishbutton");
        filterSideDish.addEventListener("click", function(){
          if (videoHolder.classList.contains("sidedish")) {
            videoHolder.style.display = "block";
            sidedishButton.classList.add("active");
          } else {
            videoHolder.style.display = "none";
            sidedishbutton.classList.remove("active");
          }
        });
        
        let filterBeverage = document.querySelector(".beverage");
        let beverageButton = document.querySelector(".beveragebutton");
        filterBeverage.addEventListener("click", function(){
          if (videoHolder.classList.contains("beverage")) {
            videoHolder.style.display = "block";
            beverageButton.classList.add("active");
          } else {
            videoHolder.style.display = "none";
            beveragebutton.classList.remove("active");
          }
        });
        
        let filterIngredient = document.querySelector(".ingredient");
        let ingredientButton = document.querySelector(".ingredientbutton");
        filterIngredient.addEventListener("click", function(){
          if (videoHolder.classList.contains("ingredient")) {
            videoHolder.style.display = "block";
            ingredientButton.classList.add("active");
          } else {
            videoHolder.style.display = "none";
            ingredientbutton.classList.remove("active");
          }
        });

    });
  }
